'''
Collection of utility pipes for supporting more complex pipelines.

@author: twong / kyocum
@copyright: Human Longevity, Inc. 2017
@license: Apache 2.0
'''
