
.. figure:: ./docs/DisdatTitleFig.jpg
   :alt: Disdat Logo
   :align: center

Disdat is a Python (2.7) package for data versioning and pipeline authoring that allows data scientists to create,
share, and track data products.  Disdat organizes data into *bundles*, collections of literal values and files --
bundles are the unit at which data is versioned and shared.   Disdat pipelines automatically create bundles, making
it easy to produce and then share the latest outputs with other users.  Instead of lengthy email conversations with
multiple file attachments, searching through Slack for the most recent S3 file path, users can instead
``dsdt pull awesome_data`` to get the latest 'awesome_data.'


Getting Started
---------------

Disdat includes both an API and a CLI (command-line interface).  To install either, first clone the disdat code repository:

.. code-block:: console

    $ git clone git@github.com:kyocum/disdat.git

At this point you can either install the stand-alone version ( `Install the CLI`_) or you can install the package (`Install the package`_).
The first will install a `dsdt`binary that can be used independent from any Python virtual environment.   The second
will install the CLI within a particular virtual environment, but also install the Disdat API so that you can manage data
and run pipelines within Python code.


Install the CLI
---------------

Build and install the single-file `dsdt` executable.   The deactivate command is optional if you're currently in an existing Python virtual environment.

.. code-block:: console

    $ deactivate
    $ cd disdat
    $ ./build-dist.sh
    $ cp dist/dsdt /usr/local/bin/.
    $ chmod u+x /usr/local/bin/dsdt

You now have a functioning `dsdt` excutable that you can use create and pull bundles, as well as run Disdat pipelines.


Install the API/Package
-----------------------

If you want to write Python code that works directly with bundles and pipelines, then you'll need to install the
source distribution.  Assume you are already in your virtual environment.

Install disdat

.. code-block:: console

    $ cd disdat
    $ python setup.py install


Install for developers
-------------------------

Create a new virtual environment for Disdat:

.. code-block:: console

    $ mkvirtualenv disdat

Install disdat

.. code-block:: console

    $ cd disdat
    $ pip install -e .

Execute disdat:

.. code-block:: console

    $ dsdt

Short Test Drive
----------------

First, Disdat needs to setup some minimal configuration.   Second, create a data *context* in which to store the data
you will track and share.  Finally, switch into that context.   The commands `dsdt context` and `dsdt switch` are kind of like
`git branch` and `git checkout`.  However, we use different terms because contexts don't always behave like code repositories.

.. code-block:: console

    $ dsdt init
    $ dsdt context mycontext
    $ dsdt switch mycontext









Background
----------

Disdat provides an ecosystem for data creation, versioning, and sharing.  One might be tempted to say it is 'git for
data.'   However, it's more like the bastard love child of iPhoto, git, and Python virtual environments. First Disdat
organizes all data into immutable sets called *hyperframes*.   Most users are never aware of this underlying
structure -- they simply import or process collections of files and values to create new ones.  Going forward we'll
call these collections data sets or bundles.  In this way, Disdat is like iPhoto.  Users import their data into
Disdat, which manages and tracks changes to these data sets as the user examines and processes them. Like git, Disdat
provides data contexts, repositories that represent indepenent name spaces for data sets.   The Disdat command line
facility allows for branching and checking out a copy of contexts.   But, unlike git, one doesn't have to be in a
certain directory on your local filesystem to be in that context.  Instead, like a virtual environment, one remains
within a data context branch until they explicity change to another.

In Disdat, users create data set bundles by importing CSV files, directories containing files, or both.   Users may then
execute *pipelines* that a bundle as input and produce a bundle as output. Users specify processing pipelines using a
Python interface based on  `Luigi <https://luigi.readthedocs.io/en/stable/>`_, an existing pipelining system developed
by Spotify.  We think Luigi is great, and if you're used to writing Luigi pipelines, then you'll feel *mostly* at home.

Disdat enhances Luigi pipelines in the following ways:

* Simplified pipeline specifications -- users implement up to two (not three) functions per task and all tasks see the pipeline's input bundle.

* Enhanced re-execution logic -- Disdat re-runs processing steps when code or data changes.

* Automatically tracked data lineage -- Users can see code and data versions used to create each output data set.

* Search, find, share data sets -- Uses may push and pull data to remote contexts.

* Disdat allows a principled approach to cleaning local and shared storage systems.   Data may be easily cleaned by user, date, or by version.

* [Coming] Scale-out pipelines -- Disdat can *autodock* pipelines to Docker containers, allowing them to run on your favorite container execution service such as AWS ECS or Kubernetes.

Authors
----------

Disdat was conceived of by Ken Yocum while at Human Longevity, Inc.  Dr. Yocum has been the primary contributor, but
it has strongly benefited from numerous discussions, code contributions, and emotional support from Jonathon Lunt,
Ted Wong, Jason Knight, and Axel Bernel.
